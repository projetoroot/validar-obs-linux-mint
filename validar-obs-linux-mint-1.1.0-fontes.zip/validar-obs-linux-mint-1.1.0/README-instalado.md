# Validador do OBS Studio 1.1.0

Aplicativo para Linux Mint e distribuições baseadas em Ubuntu.

## Interface

A interface foi migrada para GTK 3, por isso utiliza o tema GTK ativo no Linux Mint Cinnamon, incluindo estilos dos botões, campos, barras de rolagem e janelas do sistema.

## Recursos

- Auditoria de configurações e perfis do OBS Studio.
- Verificação de codificador, formato, resolução, FPS e faixas de áudio.
- Consulta de NVIDIA, monitores, servidor de áudio e logs recentes.
- Exportação de relatório em TXT ou HTML.
- Copiar relatório para a área de transferência.
- Operação somente de leitura. O programa não modifica configurações do OBS.

## Iniciar

No menu do Linux Mint, abra Multimídia > Validador do OBS Studio.

Também é possível executar `validar-obs-linux-mint` em um terminal.

## Dependências

O APT instala automaticamente Python 3, bindings GTK 3, introspecção GTK 3 e utilitários usados na auditoria, conforme as dependências do pacote.

## Configurações

O aplicativo lê os arquivos do OBS no perfil do usuário e não os modifica.
