# Validador do OBS Studio para Linux Mint 1.1.0

Esta versão substitui a interface Tkinter por GTK 3. A janela, os botões e os diálogos de arquivo usam o tema GTK configurado no sistema Linux Mint Cinnamon, incluindo tema claro ou escuro escolhido pelo usuário.

## Novidades da versão 1.1.0

- Interface gráfica nativa GTK 3, seguindo o tema GTK ativo.
- Botões separados para exportar o relatório como `.txt` ou `.html`.
- O HTML tem seções, cores para OK/AVISO/INFO/FALHA, visual adaptável a tema claro/escuro e estilos de impressão.
- Saída de ferramentas de sistema limpa de sequências de controle conhecidas.
- O aplicativo continua em modo somente leitura.
- Instalação em caminhos de sistema: `/usr/bin`, `/usr/share` e `/usr/share/applications`.
- Atalho de menu na categoria Multimídia.

## Instalar o pacote

```bash
sudo apt install ./validar-obs-linux-mint_1.1.0_all.deb
```

O APT instala automaticamente as dependências GTK e os utilitários necessários. Depois abra o menu Multimídia e procure por `Validador do OBS Studio`.

## Exportar relatórios

1. Abra o aplicativo e clique em `Executar auditoria`.
2. Clique em `Exportar TXT` para salvar o relatório de texto.
3. Clique em `Exportar HTML` para salvar uma página formatada que pode ser aberta no navegador ou impressa.

Os diálogos começam na pasta pessoal do usuário e permitem escolher outro destino.

## Construir o pacote a partir das fontes

O arquivo `build-package.sh` cria um pacote `.deb` usando `dpkg-deb` e não instala nada no sistema durante a construção.

```bash
chmod +x build-package.sh
./build-package.sh
```

## Dependências declaradas

- `python3 (>= 3.12)`
- `python3-gi`
- `gir1.2-gtk-3.0`
- `inxi`
- `x11-xserver-utils`
- `pulseaudio-utils`
- `desktop-file-utils`

O código de auditoria pode ser executado em modo texto com `--audit`, útil para diagnóstico automatizado.
