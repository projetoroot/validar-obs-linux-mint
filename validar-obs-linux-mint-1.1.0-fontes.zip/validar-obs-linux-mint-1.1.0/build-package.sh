#!/bin/sh
set -eu
BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
VERSION=1.1.0
PKG_DIR="$BASE_DIR/pkg"
OUT="$BASE_DIR/validar-obs-linux-mint_${VERSION}_all.deb"
command -v dpkg-deb >/dev/null 2>&1 || { echo "dpkg-deb não encontrado. Instale dpkg-dev." >&2; exit 1; }
install -m 0755 "$BASE_DIR/src/validar_obs_linux_mint_gui.py" \
  "$PKG_DIR/usr/share/validar-obs-linux-mint/validar_obs_linux_mint_gui.py"
chmod -R g-s "$PKG_DIR"
chmod 0755 "$PKG_DIR" "$PKG_DIR/DEBIAN"
dpkg-deb --build --root-owner-group "$PKG_DIR" "$OUT"
echo "Pacote gerado: $OUT"
