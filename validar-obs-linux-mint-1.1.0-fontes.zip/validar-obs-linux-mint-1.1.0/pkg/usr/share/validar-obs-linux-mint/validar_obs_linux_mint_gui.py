#!/usr/bin/env python3
"""Auditoria somente leitura do OBS Studio no Linux Mint/Ubuntu.

Não altera configurações, não instala pacotes e não reinicia o OBS.
Não lê service.json nem arquivos de credenciais/chaves de transmissão.
"""
from __future__ import annotations

import configparser
import datetime as dt
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional

HOME = Path.home()


def run(cmd: list[str], timeout: int = 5) -> tuple[int, str]:
    try:
        proc = subprocess.run(
            cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            timeout=timeout, check=False, env={**os.environ, "LC_ALL": "C"}
        )
        output = proc.stdout or ""
        output = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", output)
        output = re.sub(r"\x03\d*|\x04\d*", "", output)
        output = "".join(ch for ch in output if ch in "\n\r\t" or ord(ch) >= 32)
        return proc.returncode, output.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired, PermissionError) as exc:
        return 127, str(exc)


def title(text: str) -> None:
    print(f"\n=== {text} ===")


def result(level: str, message: str) -> None:
    icon = {"OK": "[OK]", "AVISO": "[AVISO]", "INFO": "[INFO]", "FALHA": "[FALHA]"}.get(level, "[INFO]")
    print(f"{icon} {message}")


def parse_ini(path: Path) -> configparser.ConfigParser:
    cfg = configparser.ConfigParser(interpolation=None, strict=False)
    cfg.optionxform = str.lower
    try:
        with path.open("r", encoding="utf-8", errors="replace") as f:
            cfg.read_file(f)
    except (OSError, configparser.Error) as exc:
        result("AVISO", f"Não foi possível ler {path}: {exc}")
    return cfg


def get(cfg: configparser.ConfigParser, section: str, key: str, default: str = "") -> str:
    if cfg.has_section(section) and cfg.has_option(section, key.lower()):
        try:
            return cfg.get(section, key.lower()).strip()
        except (configparser.Error, ValueError):
            return default
    return default


def find_config_roots() -> list[Path]:
    candidates = [
        Path(os.environ.get("XDG_CONFIG_HOME", HOME / ".config")) / "obs-studio",
        HOME / ".config" / "obs-studio",
        HOME / ".var" / "app" / "com.obsproject.Studio" / "config" / "obs-studio",
        HOME / "snap" / "obs-studio" / "current" / ".config" / "obs-studio",
    ]
    roots: list[Path] = []
    seen: set[str] = set()
    for path in candidates:
        expanded = path.expanduser()
        key = str(expanded)
        if key not in seen and expanded.is_dir():
            roots.append(expanded)
            seen.add(key)
    return roots


def detect_installations() -> None:
    found = False
    if shutil.which("obs"):
        result("INFO", f"Executável encontrado no PATH: {shutil.which('obs')}")
        # Não executa o binário do OBS para evitar abrir uma segunda instância.
        found = True

    code, out = run(["dpkg-query", "-W", "-f=${Package} ${Version}\n", "obs-studio"])
    if code == 0 and out:
        result("INFO", f"Pacote APT/DPKG: {out}")
        found = True

    code, out = run(["flatpak", "info", "com.obsproject.Studio"])
    if code == 0 and out:
        lines = [line.strip() for line in out.splitlines() if line.strip()]
        result("INFO", "Flatpak instalado: " + (lines[0] if lines else "com.obsproject.Studio"))
        for line in lines:
            if line.lower().startswith(("version:", "branch:", "installation:")):
                result("INFO", line)
        found = True

    code, out = run(["snap", "list", "obs-studio"])
    if code == 0 and out:
        result("INFO", "Snap instalado: " + out.splitlines()[-1])
        found = True

    if not found:
        result("AVISO", "Não consegui identificar a instalação do OBS pelos gerenciadores conhecidos.")


def value_for_profile(cfg: configparser.ConfigParser, mode: str, keys: list[tuple[str, str]]) -> str:
    for section, key in keys:
        val = get(cfg, section, key)
        if val:
            return val
    return "não informado"


def inspect_encoder_json(profile_dir: Path) -> dict:
    """Retorna apenas opções de codificação relevantes; não despeja o JSON completo."""
    collected: dict = {}
    for filename in ("recordEncoder.json", "streamEncoder.json"):
        p = profile_dir / filename
        if not p.is_file():
            continue
        try:
            data = json.loads(p.read_text(encoding="utf-8", errors="replace"))
        except (OSError, json.JSONDecodeError):
            continue
        # Dependendo da versão do OBS, as opções podem estar no nível superior ou aninhadas.
        def walk(obj, depth=0):
            if depth > 5:
                return
            if isinstance(obj, dict):
                for k, v in obj.items():
                    kl = str(k).lower()
                    if kl in {"rate_control", "ratecontrol", "cqp", "qp", "cq", "preset", "profile", "lookahead", "psycho_aq", "psycho_visual_tuning", "bf", "keyint_sec", "keyint", "gop_size"}:
                        if isinstance(v, (str, int, float, bool)):
                            collected[f"{filename}:{k}"] = v
                    if isinstance(v, (dict, list)):
                        walk(v, depth + 1)
            elif isinstance(obj, list):
                for item in obj:
                    walk(item, depth + 1)
        walk(data)
    return collected


def inspect_profile(profile_dir: Path, active: bool) -> None:
    ini = profile_dir / "basic.ini"
    if not ini.is_file():
        return
    cfg = parse_ini(ini)
    mode = get(cfg, "Output", "Mode", "Simple") or "Simple"
    mode_lower = mode.lower()
    if mode_lower not in ("simple", "advanced"):
        mode_lower = "advanced" if "adv" in mode_lower else "simple"

    title(f"Perfil: {profile_dir.name}" + (" (selecionado no arquivo global)" if active else ""))
    result("INFO", f"Modo de saída: {mode}")
    if not active:
        result("INFO", "Este perfil pode não ser o perfil atualmente em uso.")

    if mode_lower == "advanced":
        enc = value_for_profile(cfg, mode, [("AdvOut", "RecEncoder"), ("AdvOut", "Encoder")])
        audio_enc = value_for_profile(cfg, mode, [("AdvOut", "RecAudioEncoder"), ("AdvOut", "AudioEncoder")])
        fmt = value_for_profile(cfg, mode, [("AdvOut", "RecFormat2"), ("AdvOut", "RecFormat")])
        tracks = get(cfg, "AdvOut", "RecTracks")
        rec_path = get(cfg, "AdvOut", "RecFilePath") or get(cfg, "AdvOut", "FFFilePath")
    else:
        enc = value_for_profile(cfg, mode, [("SimpleOutput", "RecEncoder")])
        audio_enc = value_for_profile(cfg, mode, [("SimpleOutput", "RecAudioEncoder")])
        fmt = value_for_profile(cfg, mode, [("SimpleOutput", "RecFormat2")])
        tracks = get(cfg, "SimpleOutput", "RecTracks")
        rec_path = get(cfg, "SimpleOutput", "FilePath")

    result("INFO", f"Codificador de vídeo configurado: {enc}")
    enc_low = enc.lower()
    if "nvenc" in enc_low:
        result("OK", "O perfil aponta para um codificador NVENC da NVIDIA.")
    elif "x264" in enc_low or "obs_x264" in enc_low:
        result("AVISO", "O perfil parece usar x264 por software, não o NVENC da NVIDIA.")
    elif enc == "não informado":
        result("AVISO", "Não consegui identificar o codificador de gravação pelo basic.ini; confira no OBS.")
    else:
        result("INFO", "Verifique no OBS se o codificador escolhido corresponde ao hardware desejado.")

    result("INFO", f"Formato de gravação: {fmt}")
    fmt_low = fmt.lower()
    if fmt_low in {"mkv", "matroska"}:
        result("OK", "MKV selecionado, adequado para reduzir o risco de perder a gravação se o OBS fechar inesperadamente.")
    elif fmt == "não informado":
        result("AVISO", "Formato de gravação não localizado no arquivo do perfil.")
    else:
        result("AVISO", "Para gravações locais, considere MKV e remux para MP4 depois, se necessário.")

    result("INFO", f"Codificador de áudio: {audio_enc}")
    if audio_enc.lower() in {"libfdk_aac", "ffmpeg_aac", "aac", "coreaudio_aac"}:
        result("OK", "Codificador AAC reconhecido.")
    elif audio_enc == "não informado":
        result("AVISO", "Codificador de áudio não localizado no basic.ini; confira no OBS.")
    else:
        result("INFO", "O codificador de áudio pode ser válido; confirme compatibilidade com o formato de gravação.")

    if tracks:
        try:
            track_mask = int(tracks, 0)
            if track_mask == 0:
                result("FALHA", "RecTracks está em zero, o que pode indicar que nenhuma faixa está marcada para gravação.")
            else:
                enabled = [str(bit) for bit in range(1, 7) if track_mask & (1 << (bit - 1))]
                result("INFO", f"Máscara das faixas de gravação: {track_mask}; faixas marcadas: {', '.join(enabled) if enabled else 'não identificadas'}")
        except ValueError:
            result("INFO", f"Faixas de gravação configuradas: {tracks}")
    else:
        result("AVISO", "Não consegui ler a configuração das faixas de áudio de gravação.")

    vid = {
        "Resolução base": f"{get(cfg, 'Video', 'BaseCX')}x{get(cfg, 'Video', 'BaseCY')}" if get(cfg, 'Video', 'BaseCX') and get(cfg, 'Video', 'BaseCY') else "não informada",
        "Resolução de saída": f"{get(cfg, 'Video', 'OutputCX')}x{get(cfg, 'Video', 'OutputCY')}" if get(cfg, 'Video', 'OutputCX') and get(cfg, 'Video', 'OutputCY') else "não informada",
        "FPS": get(cfg, "Video", "FPSCommon") or (f"{get(cfg, 'Video', 'FPSNum')}/{get(cfg, 'Video', 'FPSDen')}" if get(cfg, 'Video', 'FPSNum') and get(cfg, 'Video', 'FPSDen') else "não informado"),
        "Filtro de redução": get(cfg, "Video", "ScaleType") or "não informado",
        "Formato de cor": get(cfg, "Video", "ColorFormat") or "não informado",
        "Espaço de cor": get(cfg, "Video", "ColorSpace") or "não informado",
        "Faixa de cor": get(cfg, "Video", "ColorRange") or "não informado",
    }
    for k, v in vid.items():
        result("INFO", f"{k}: {v}")

    sample_rate = get(cfg, "Audio", "SampleRate")
    channels = get(cfg, "Audio", "ChannelSetup")
    result("INFO", f"Áudio global: {sample_rate or 'não informado'} Hz, {channels or 'não informado'}")
    if sample_rate == "48000":
        result("OK", "Taxa de amostragem de áudio em 48 kHz.")
    elif sample_rate:
        result("AVISO", "Para gravação de vídeo, 48 kHz costuma ser a configuração recomendada.")
    else:
        result("AVISO", "Taxa de amostragem não localizada no arquivo do perfil.")
    if channels.lower() == "stereo":
        result("OK", "Áudio configurado em estéreo.")
    elif channels:
        result("AVISO", "Confirme se a disposição de canais corresponde às suas fontes de áudio.")

    enc_settings = inspect_encoder_json(profile_dir)
    if enc_settings:
        result("INFO", "Opções encontradas nos arquivos do codificador:")
        for k, v in enc_settings.items():
            result("INFO", f"  {k} = {v}")
        cqp_values = [v for k, v in enc_settings.items() if k.lower().endswith(":cqp") or k.lower().endswith(":cq") or k.lower().endswith(":qp")]
        if cqp_values:
            try:
                cq = float(cqp_values[0])
                if 18 <= cq <= 23:
                    result("OK", f"Valor CQP/CQ {cq:g} está na faixa sugerida para o teste (18 a 23).")
                else:
                    result("INFO", f"Valor CQP/CQ {cq:g}; valores menores tendem a priorizar qualidade e gerar arquivos maiores.")
            except (TypeError, ValueError):
                pass
    else:
        result("INFO", "Não encontrei opções detalhadas do codificador em recordEncoder.json/streamEncoder.json; isso pode variar entre versões do OBS.")

    if rec_path:
        p = Path(os.path.expandvars(os.path.expanduser(rec_path)))
        result("INFO", f"Diretório de gravação: {p}")
        if p.is_dir():
            try:
                free_gib = os.statvfs(p).f_bavail * os.statvfs(p).f_frsize / (1024 ** 3)
                result("OK", f"Diretório existe; espaço disponível aproximado: {free_gib:.1f} GiB.")
                if free_gib < 5:
                    result("AVISO", "Há menos de 5 GiB livres no destino de gravação.")
            except OSError:
                result("INFO", "Diretório existe, mas não consegui consultar o espaço livre.")
        else:
            result("AVISO", "O diretório configurado não existe ou não está acessível para este usuário.")
    else:
        result("INFO", "Diretório de gravação não localizado no arquivo do perfil.")


def inspect_logs(roots: list[Path]) -> None:
    candidates: list[Path] = []
    for root in roots:
        log_dir = root / "logs"
        if log_dir.is_dir():
            candidates.extend(p for p in log_dir.glob("*.txt") if p.is_file())
    if not candidates:
        result("INFO", "Nenhum log local do OBS foi encontrado nos diretórios de configuração detectados.")
        return
    latest = max(candidates, key=lambda p: p.stat().st_mtime)
    try:
        content = latest.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError as exc:
        result("AVISO", f"Não foi possível ler o log mais recente: {exc}")
        return
    result("INFO", f"Log mais recente: {latest.name}; {dt.datetime.fromtimestamp(latest.stat().st_mtime).isoformat(timespec='seconds')}")
    patterns = re.compile(
        r"nvenc|encoder overloaded|rendering lag|encoding lag|skipped frames|dropped frames|"
        r"audio buffering|xrun|underrun|failed to initialize|failed to create|"
        r"gl_invalid|device removed|pipewire|pulseaudio|pulse audio|alsa.*(error|fail)|"
        r"error.*(audio|video|encoder|graphics|capture)|warning.*(audio|video|encoder|graphics|capture)",
        re.IGNORECASE,
    )
    matches = [line.strip() for line in content if patterns.search(line)]
    if not matches:
        result("OK", "Não encontrei no log recente correspondências com os padrões de erro/atraso pesquisados.")
        return
    result("INFO", f"Linhas relevantes encontradas: {len(matches)}. Exibindo até as 18 últimas:")
    for line in matches[-18:]:
        # Limita linhas longas para não despejar dados desnecessários no terminal.
        result("INFO", line[:260])


def main() -> int:
    print("Auditoria do OBS Studio - Linux Mint")
    print("Modo somente leitura: nenhuma configuração será alterada.")
    print(f"Data: {dt.datetime.now().astimezone().isoformat(timespec='seconds')}")

    title("Sistema e sessão gráfica")
    mint_info = Path("/etc/linuxmint/info")
    if mint_info.is_file():
        for line in mint_info.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.startswith(("RELEASE=", "CODENAME=", "EDITION=", "DESCRIPTION=")):
                result("INFO", line)
    code, out = run(["uname", "-r"])
    result("INFO", f"Kernel: {out or 'não identificado'}")
    result("INFO", f"Sessão gráfica: {os.environ.get('XDG_SESSION_TYPE', 'não informada')}")
    code, out = run(["cinnamon", "--version"])
    if code == 0 and out:
        result("INFO", out.splitlines()[0])

    title("Instalação do OBS")
    detect_installations()

    title("NVIDIA")
    if shutil.which("nvidia-smi"):
        code, out = run(["nvidia-smi", "--query-gpu=name,driver_version,temperature.gpu,utilization.gpu,memory.used,memory.total", "--format=csv,noheader"], timeout=8)
        if code == 0 and out:
            result("OK", out)
        else:
            result("AVISO", f"nvidia-smi existe, mas não retornou dados: {out[:250]}")
    else:
        result("AVISO", "nvidia-smi não foi encontrado.")
    if shutil.which("inxi"):
        code, out = run(["inxi", "-Gxx"], timeout=8)
        if code == 0 and out:
            for line in out.splitlines():
                if re.search(r"Graphics:|Device-[0-9]+:|driver:|OpenGL|direct-render|Display:", line, re.IGNORECASE):
                    result("INFO", line.strip()[:240])

    title("Monitores")
    if shutil.which("xrandr") and os.environ.get("DISPLAY"):
        code, out = run(["xrandr", "--query"], timeout=6)
        if code == 0:
            lines = out.splitlines()
            for i, line in enumerate(lines):
                if " connected " in line:
                    result("INFO", line.strip())
                    # Mostra o modo atual destacado com * se estiver nas linhas seguintes.
                    for mode_line in lines[i + 1:i + 8]:
                        if "*" in mode_line:
                            result("INFO", "Modo atual: " + mode_line.strip())
                            break
    else:
        result("INFO", "xrandr não disponível nesta sessão ou não há DISPLAY definido.")

    title("Áudio do sistema")
    if shutil.which("pactl"):
        code, out = run(["pactl", "info"], timeout=5)
        if code == 0:
            for line in out.splitlines():
                if line.lower().startswith(("server name:", "server version:", "default sink:", "default source:")):
                    result("INFO", line.strip())
        for label, cmd in (("saídas", ["pactl", "list", "short", "sinks"]), ("entradas", ["pactl", "list", "short", "sources"])):
            code, out = run(cmd, timeout=5)
            if code == 0 and out:
                result("INFO", f"Dispositivos de áudio, {label}:")
                for line in out.splitlines()[:12]:
                    result("INFO", line.strip()[:220])
    elif shutil.which("wpctl"):
        code, out = run(["wpctl", "status"], timeout=5)
        if code == 0:
            result("INFO", "PipeWire/wpctl encontrado; status resumido:")
            for line in out.splitlines()[:35]:
                result("INFO", line.rstrip()[:220])
    else:
        result("AVISO", "Não encontrei pactl nem wpctl para consultar o sistema de áudio.")

    roots = find_config_roots()
    title("Arquivos de configuração do OBS")
    if not roots:
        result("FALHA", "Nenhuma pasta de configuração do OBS foi encontrada nos caminhos padrão.")
        result("INFO", "Abra o OBS uma vez e confirme em Ajuda/Arquivo onde fica a pasta de configurações.")
        return 1

    for root in roots:
        result("INFO", f"Pasta encontrada: {root}")

    selected_names: set[str] = set()
    for root in roots:
        for filename in ("global.ini", "user.ini"):
            gpath = root / filename
            if gpath.is_file():
                gcfg = parse_ini(gpath)
                profile = get(gcfg, "Basic", "Profile")
                collection = get(gcfg, "Basic", "SceneCollection")
                if profile:
                    selected_names.add(profile)
                    result("INFO", f"Perfil selecionado em {filename}: {profile}")
                if collection:
                    result("INFO", f"Coleção de cenas selecionada em {filename}: {collection}")

    profiles_found = 0
    for root in roots:
        profiles_dir = root / "basic" / "profiles"
        if not profiles_dir.is_dir():
            continue
        profile_dirs = sorted(p for p in profiles_dir.iterdir() if p.is_dir() and (p / "basic.ini").is_file())
        for profile_dir in profile_dirs:
            profiles_found += 1
            inspect_profile(profile_dir, profile_dir.name in selected_names)
    if profiles_found == 0:
        result("AVISO", "Nenhum perfil com basic.ini foi encontrado.")

    title("Log mais recente do OBS")
    inspect_logs(roots)

    title("Conclusão")
    result("INFO", "Esta auditoria lê configurações salvas. Alguns ajustes do OBS só aparecem no log depois de iniciar uma gravação de teste.")
    result("INFO", "Para investigar glitches, faça uma gravação curta e depois execute o script novamente para capturar o log atualizado.")
    result("INFO", "Antes de compartilhar o resultado, revise nomes de dispositivos, caminhos locais e nomes de fontes que apareçam nos logs.")
    return 0


def html_report(report: str) -> str:
    """Cria um relatório HTML seguro e legível a partir do relatório textual."""
    from html import escape

    generated = dt.datetime.now().astimezone().strftime("%d/%m/%Y %H:%M:%S %Z")
    blocks: list[str] = []
    for raw_line in report.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith("===") and line.endswith("==="):
            heading = line.strip("= ")
            blocks.append(f"<h2>{escape(heading)}</h2>")
            continue
        match = re.match(r"^\[(OK|AVISO|INFO|FALHA)\]\s*(.*)$", line)
        if match:
            level, message = match.groups()
            blocks.append(
                f'<p class="entry {level.lower()}"><span class="tag">{escape(level)}</span> '
                f'{escape(message)}</p>'
            )
        else:
            blocks.append(f"<p class=\"plain\">{escape(line)}</p>")
    body = "\n".join(blocks) or "<p>O relatório está vazio.</p>"
    return f'''<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Relatório do Validador do OBS Studio</title>
<style>
:root {{ color-scheme: light dark; --mint: #78b82a; --fg: #24292f; --muted: #626b73; --panel: #fff; --page: #f3f5f3; --line: #d9dfd7; }}
@media (prefers-color-scheme: dark) {{ :root {{ --fg: #e5e9e5; --muted: #aab3aa; --panel: #252925; --page: #191d19; --line: #3a4339; }} }}
* {{ box-sizing: border-box; }}
body {{ margin: 0; background: var(--page); color: var(--fg); font: 15px/1.55 system-ui, -apple-system, "Ubuntu", "Cantarell", sans-serif; }}
header {{ background: var(--panel); border-bottom: 4px solid var(--mint); padding: 24px clamp(18px, 5vw, 56px); }}
header h1 {{ margin: 0 0 4px; font-size: 1.55rem; }}
header p {{ margin: 0; color: var(--muted); }}
main {{ max-width: 1100px; margin: 24px auto; padding: 0 16px 30px; }}
.report {{ background: var(--panel); border: 1px solid var(--line); border-radius: 8px; padding: clamp(16px, 3vw, 30px); overflow-wrap: anywhere; }}
h2 {{ margin: 28px 0 12px; padding: 0 0 7px; font-size: 1.08rem; border-bottom: 1px solid var(--line); }}
h2:first-child {{ margin-top: 0; }}
.entry {{ margin: 7px 0; }}
.tag {{ display: inline-block; min-width: 58px; margin-right: 5px; font-size: .78rem; font-weight: 700; }}
.ok .tag {{ color: #4e8a19; }} .aviso .tag {{ color: #b7791f; }} .falha .tag {{ color: #c23b32; }} .info .tag {{ color: var(--muted); }}
.plain {{ margin: 7px 0; }}
footer {{ padding: 0 16px 24px; text-align: center; color: var(--muted); font-size: .85rem; }}
@media print {{ body {{ background: #fff; color: #111; }} header, .report {{ background: #fff; }} main {{ margin: 0 auto; }} }}
</style>
</head>
<body>
<header><h1>Validador do OBS Studio</h1><p>Relatório de auditoria • Linux Mint e sistemas baseados em Ubuntu</p><p>Exportado em {escape(generated)}</p></header>
<main><section class="report">{body}</section></main>
<footer>Auditoria somente de leitura. Revise nomes de dispositivos, caminhos e fontes antes de compartilhar.</footer>
</body>
</html>
'''


def launch_gui() -> None:
    """Interface GTK 3 nativa que herda o tema GTK ativo no Linux Mint Cinnamon."""
    try:
        import gi
        gi.require_version("Gtk", "3.0")
        from gi.repository import Gtk, Gdk, GLib, Pango
    except (ImportError, ValueError) as exc:
        message = (
            "Não foi possível carregar a interface GTK do sistema.\n\n"
            "Instale as dependências com:\n"
            "sudo apt install python3-gi gir1.2-gtk-3.0\n\n"
            f"Detalhe: {exc}"
        )
        if shutil.which("zenity"):
            subprocess.run(["zenity", "--error", "--title=Validador do OBS Studio", f"--text={message}"], check=False)
        else:
            print(message, file=sys.stderr)
        return

    Gtk.init_check(None)
    window = Gtk.Window(title="Validador do OBS Studio")
    window.set_default_size(1080, 760)
    window.set_size_request(760, 520)
    window.set_position(Gtk.WindowPosition.CENTER)
    window.set_icon_name("validar-obs-linux-mint")
    window.connect("destroy", Gtk.main_quit)

    outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
    outer.set_border_width(14)
    window.add(outer)

    title_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
    title_icon = Gtk.Image.new_from_icon_name("validar-obs-linux-mint", Gtk.IconSize.DIALOG)
    title_icon.set_pixel_size(48)
    title_row.pack_start(title_icon, False, False, 0)
    title_stack = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
    title_label = Gtk.Label()
    title_label.set_markup("<span size='x-large' weight='bold'>Validador do OBS Studio</span>")
    title_label.set_xalign(0)
    title_stack.pack_start(title_label, False, False, 0)
    subtitle = Gtk.Label(
        label="Auditoria de vídeo, áudio, NVIDIA, monitores e logs. Não altera configurações do OBS."
    )
    subtitle.set_xalign(0)
    subtitle.set_line_wrap(True)
    subtitle.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
    title_stack.pack_start(subtitle, False, False, 0)
    title_row.pack_start(title_stack, True, True, 0)
    outer.pack_start(title_row, False, False, 0)

    separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
    outer.pack_start(separator, False, False, 1)

    toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=7)
    outer.pack_start(toolbar, False, False, 0)

    def make_button(label: str, icon_name: str, tooltip: str) -> Gtk.Button:
        button = Gtk.Button.new_with_mnemonic(label)
        image = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.BUTTON)
        button.set_image(image)
        button.set_always_show_image(True)
        button.set_tooltip_text(tooltip)
        return button

    run_button = make_button("_Executar auditoria", "system-run-symbolic", "Executar a verificação do sistema e do OBS")
    save_txt_button = make_button("Exportar _TXT", "text-x-generic-symbolic", "Salvar o relatório em texto simples")
    save_html_button = make_button("Exportar _HTML", "text-html-symbolic", "Salvar o relatório formatado como página HTML")
    copy_button = make_button("_Copiar", "edit-copy-symbolic", "Copiar o relatório para a área de transferência")
    clear_button = make_button("_Limpar", "edit-clear-symbolic", "Limpar a área de relatório")
    close_button = make_button("_Fechar", "window-close-symbolic", "Fechar o aplicativo")
    for button in (run_button, save_txt_button, save_html_button, copy_button, clear_button):
        toolbar.pack_start(button, False, False, 0)
    toolbar.pack_end(close_button, False, False, 0)

    scrolled = Gtk.ScrolledWindow()
    scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
    scrolled.set_shadow_type(Gtk.ShadowType.IN)
    scrolled.set_hexpand(True)
    scrolled.set_vexpand(True)
    outer.pack_start(scrolled, True, True, 0)

    output = Gtk.TextView()
    output.set_editable(False)
    output.set_cursor_visible(True)
    output.set_monospace(True)
    output.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
    output.set_left_margin(12)
    output.set_right_margin(12)
    output.set_top_margin(12)
    output.set_bottom_margin(12)
    output.get_style_context().add_class("view")
    buffer = output.get_buffer()
    scrolled.add(output)

    status = Gtk.Label(label="Pronto. Clique em Executar auditoria para começar.")
    status.set_xalign(0)
    status.set_ellipsize(Pango.EllipsizeMode.END)
    outer.pack_start(status, False, False, 0)

    initial = (
        "A auditoria não instala pacotes, não altera arquivos e não reinicia o OBS.\n"
        "Para obter logs úteis, abra o OBS e faça uma gravação curta antes de executar a verificação.\n\n"
        "Clique em Executar auditoria. O relatório aparecerá nesta janela.\n"
    )
    buffer.set_text(initial)
    save_txt_button.set_sensitive(False)
    save_html_button.set_sensitive(False)
    copy_button.set_sensitive(False)

    def set_output(text: str) -> None:
        buffer.set_text(text)
        end_iter = buffer.get_end_iter()
        output.scroll_to_iter(end_iter, 0.0, False, 0.0, 1.0)

    def get_output() -> str:
        start_iter, end_iter = buffer.get_bounds()
        return buffer.get_text(start_iter, end_iter, True)

    def show_message(kind, heading: str, message: str) -> None:
        dialog = Gtk.MessageDialog(
            transient_for=window,
            flags=Gtk.DialogFlags.MODAL,
            message_type=kind,
            buttons=Gtk.ButtonsType.OK,
            text=heading,
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()

    def audit_finished(report: str | None, error: str | None, returncode: int = 0) -> None:
        run_button.set_sensitive(True)
        if error:
            set_output("Não foi possível concluir a auditoria.\n\n" + error)
            status.set_text("Falha ao executar a auditoria.")
            show_message(Gtk.MessageType.ERROR, "Erro na auditoria", error)
            return
        clean_report = report or "A auditoria terminou sem produzir saída. Verifique a instalação do Python."
        set_output(clean_report)
        if returncode == 0:
            status.set_text("Auditoria concluída. Revise os avisos do relatório.")
        else:
            status.set_text(f"Auditoria terminou com código {returncode}. Revise o relatório.")
        save_txt_button.set_sensitive(True)
        save_html_button.set_sensitive(True)
        copy_button.set_sensitive(True)

    def run_audit(_button=None) -> None:
        run_button.set_sensitive(False)
        save_txt_button.set_sensitive(False)
        save_html_button.set_sensitive(False)
        copy_button.set_sensitive(False)
        set_output("Executando a auditoria...\n\nAguarde. Nenhuma configuração será alterada.\n")
        status.set_text("Executando verificações do sistema e do OBS...")

        def worker() -> None:
            try:
                proc = subprocess.run(
                    [sys.executable, str(Path(__file__).resolve()), "--audit"],
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    timeout=180,
                    check=False,
                )
                report = proc.stdout or ""
                if proc.stderr:
                    report += "\n\n=== Mensagens adicionais ===\n" + proc.stderr
                GLib.idle_add(audit_finished, report, None, proc.returncode)
            except subprocess.TimeoutExpired:
                GLib.idle_add(audit_finished, None, "A auditoria excedeu o limite de 180 segundos.", 1)
            except Exception as exc:
                GLib.idle_add(audit_finished, None, f"{type(exc).__name__}: {exc}", 1)

        import threading
        threading.Thread(target=worker, daemon=True).start()

    def export_report(extension: str) -> None:
        content = get_output()
        if not content.strip() or content.startswith("Executando a auditoria..."):
            show_message(Gtk.MessageType.INFO, "Relatório indisponível", "Execute a auditoria antes de exportar.")
            return
        is_html = extension == ".html"
        dialog = Gtk.FileChooserDialog(
            title="Exportar relatório para HTML" if is_html else "Exportar relatório para TXT",
            parent=window,
            action=Gtk.FileChooserAction.SAVE,
        )
        dialog.add_buttons("_Cancelar", Gtk.ResponseType.CANCEL, "_Salvar", Gtk.ResponseType.ACCEPT)
        dialog.set_default_response(Gtk.ResponseType.ACCEPT)
        dialog.set_do_overwrite_confirmation(True)
        stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
        dialog.set_current_name(f"relatorio-obs-{stamp}{extension}")
        try:
            dialog.set_current_folder(str(HOME))
        except Exception:
            pass
        file_filter = Gtk.FileFilter()
        file_filter.set_name("Documento HTML (*.html)" if is_html else "Texto simples (*.txt)")
        file_filter.add_pattern("*.html" if is_html else "*.txt")
        dialog.add_filter(file_filter)
        response = dialog.run()
        filename = dialog.get_filename() if response == Gtk.ResponseType.ACCEPT else None
        dialog.destroy()
        if not filename:
            return
        if not filename.lower().endswith(extension):
            filename += extension
        try:
            output_content = html_report(content) if is_html else content.rstrip() + "\n"
            Path(filename).write_text(output_content, encoding="utf-8")
            status.set_text(f"Relatório exportado: {filename}")
            show_message(Gtk.MessageType.INFO, "Exportação concluída", f"O relatório foi salvo em:\n{filename}")
        except OSError as exc:
            show_message(Gtk.MessageType.ERROR, "Não foi possível salvar", str(exc))

    def copy_report(_button=None) -> None:
        clipboard = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
        clipboard.set_text(get_output(), -1)
        clipboard.store()
        status.set_text("Relatório copiado para a área de transferência.")

    def clear_report(_button=None) -> None:
        set_output("")
        status.set_text("Relatório limpo.")
        save_txt_button.set_sensitive(False)
        save_html_button.set_sensitive(False)
        copy_button.set_sensitive(False)

    run_button.connect("clicked", run_audit)
    save_txt_button.connect("clicked", lambda _btn: export_report(".txt"))
    save_html_button.connect("clicked", lambda _btn: export_report(".html"))
    copy_button.connect("clicked", copy_report)
    clear_button.connect("clicked", clear_report)
    close_button.connect("clicked", lambda _btn: window.destroy())

    window.show_all()
    Gtk.main()


if __name__ == "__main__":
    if "--audit" in sys.argv[1:]:
        try:
            sys.exit(main())
        except KeyboardInterrupt:
            print("\nInterrompido pelo usuário.", file=sys.stderr)
            sys.exit(130)
    else:
        launch_gui()
